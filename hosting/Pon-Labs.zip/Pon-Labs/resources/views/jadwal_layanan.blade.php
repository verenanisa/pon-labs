@extends('layouts.main')

@section('container')
<div class="container my-3">
    <h3 class="title-text-bold">Jadwal Layanan</h3>
    <img src="IMG/jadwal_layanan.jpg" class="img-fluid" alt="...">
</div>
@endsection