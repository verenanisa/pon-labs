

<?php $__env->startSection('container'); ?>
<!-- News -->
<div class="container berita my-3">
    <h3 class="title-text-bold mb-3">Pengumuman Lainnya</h3>

    <div class="row justify-content-end mb-3">
        <div class="col-md-6">
            <form action="/informasi">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Cari Pengumuman" name="cariinformasi" value="<?php echo e(request('cariinformasi')); ?>">
                    <button class="btn btn-outline-secondary" type="submit">Cari</button>
                </div>
            </form>
        </div>
    </div>

    <div class="row row-cols-1 row-cols-lg-3 g-4">
        <?php $__currentLoopData = $informasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $informasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title sub-title-bold"><a href="/informasi/<?php echo e($informasi->slug); ?>" class="text-decoration-none"><?php echo e($informasi->judul_pengumuman); ?></a></h5>
                    <p class="card-text body-text"><?php echo e($informasi->excerpt); ?></p>
                    <a href="/informasi/<?php echo e($informasi->slug); ?>" class="text-decoration-none">Lihat lebih banyak...</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<!-- End of News -->
<!-- Pagination -->
<nav aria-label="Page navigation example">
    <ul class="pagination justify-content-center">
        <li class="page-item">
            <a class="page-link" href="#" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>
            </a>
        </li>
        <li class="page-item"><a class="page-link" href="#">1</a></li>
        <li class="page-item"><a class="page-link" href="#">2</a></li>
        <li class="page-item"><a class="page-link" href="#">3</a></li>
        <li class="page-item">
            <a class="page-link" href="#" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
            </a>
        </li>
    </ul>
</nav>
<!-- End of Pagination -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 4\Praktikum Pemrograman Web\UAS\TugasAkhirWeb_064_066_075_090\Pon-Labs\resources\views/informasi.blade.php ENDPATH**/ ?>