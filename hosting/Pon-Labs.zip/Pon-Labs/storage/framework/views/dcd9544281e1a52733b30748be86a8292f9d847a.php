<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pon-Labs | Home</title>
</head>

<body>
    <h1>Halaman Login</h1>
</body>

</html><?php /**PATH D:\Kuliah\Semester 4\Praktikum Pemrograman Web\UAS\TugasAkhirWeb_064_066_075_090\Pon-Labs\resources\views/login.blade.php ENDPATH**/ ?>