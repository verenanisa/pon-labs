

<?php $__env->startSection('container'); ?>
<div class="container my-3">
    <h3 class="title-text-bold">Jadwal Layanan</h3>
    <img src="IMG/jadwal_layanan.jpg" class="img-fluid" alt="...">
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 4\Praktikum Pemrograman Web\UAS\TugasAkhirWeb_064_066_075_090\Pon-Labs\resources\views/jadwal_layanan.blade.php ENDPATH**/ ?>