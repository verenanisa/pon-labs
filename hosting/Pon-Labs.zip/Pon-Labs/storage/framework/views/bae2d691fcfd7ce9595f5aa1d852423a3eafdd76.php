

<?php $__env->startSection('container'); ?>
<div class="container berita my-3">
    <h3 class="title-text-bold"><?php echo e($berita->judul_berita); ?></h3>
    <div class="body-text" style="font-weight: 200px;">
        <?php echo $berita->isi_berita; ?>

    </div>
    <a href="/berita">Lihat berita lainnya</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 4\Praktikum Pemrograman Web\UAS\TugasAkhirWeb_064_066_075_090\Pon-Labs\resources\views/isiberita.blade.php ENDPATH**/ ?>